import Ember from 'ember';
import InfiniteScrollMixin from 'ghost/mixins/infinite-scroll';

export default Ember.Component.extend(InfiniteScrollMixin);
