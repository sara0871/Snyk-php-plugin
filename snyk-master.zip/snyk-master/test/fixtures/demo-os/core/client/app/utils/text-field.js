import Ember from 'ember';
Ember.TextField.reopen({
    attributeBindings: ['autofocus']
});
