require('./acceptance/cli.acceptance.test.js');
