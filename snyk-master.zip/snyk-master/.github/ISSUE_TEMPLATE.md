- `node -v`:
- `npm -v`:
- `snyk -v`:
- Command run:

### Expected behaviour


### Actual behaviour


### Steps to reproduce


---

If applicable, please append the `--debug` flag on your command and include the output here **ensuring to remove any sensitive/personal details or tokens.